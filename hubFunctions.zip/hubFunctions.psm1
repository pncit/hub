function Close-CwmTicket {
    <#
    .SYNOPSIS 
    Closes a ConnectWise Manage ticket

    .DESCRIPTION
    Sets a ticket to "closed" status. This status differs for service and project tickets, and the exact values are defined elsewhere as global parameters ($cwmServiceTicketStatusClosed and $cwmProjectTicketStatusClosed).

    .PARAMETER ticketId
    The id (as defined within ConnectWise Manage) of the ticket to close

    .PARAMETER apiUrl
    ConnectWise Manage API URL

    .PARAMETER authString
    ConnectWise Manage API authorization string
    
    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .EXAMPLE
    Close-CwmTicket -ticketId 12345678 -apiUrl "https://api-na.myconnectwise.net/v2019_4/apis/3.0/" -authString "Basic ZmRqa2VvaXdmaithZHNmYXNkZmFzZmRkZmZpOmZkaWVqZmlkamZpZGZkZmo="

    .OUTPUTS
    [System.Object] custom object containing ticket data
    #>
    Param(
    
        [Parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [int]$ticketId,

        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$apiUrl=$global:cwmApiUrl,
    
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$authString=$global:cwmApiAuthString,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiClientId=$global:cwmApiClientId
    
    )

    if ( $global:cwmApiConfigured -eq $false ) {
        return $null
    }
    try {
        $endpoint = "service/tickets/$ticketId"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString -apiClientId $apiClientId -ErrorAction silentlycontinue
        $closedStatus = $global:cwmServiceTicketStatusClosed
    } catch {
        $endpoint = "project/tickets/$ticketId"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString -apiClientId $apiClientId
        $closedStatus = $global:cwmProjectTicketStatusClosed
    }
    
    $body = @{
        op = "replace"
        path = "status"
        value = @{ id = $closedStatus }
    } | ConvertTo-Json
    $body = "[$body]"

    $ticket = New-CwmApiRequest -endpoint $endpoint -apiRequestBody $body -apiMethod "patch" -apiUrl $cwmApiUrl -authString $cwmApiAuthString -apiClientId $apiClientId
    return $ticket
}
function Convert-CwmCompanyNameToId {
    <#
    .SYNOPSIS 
    Returns the ConnectWise Manage id for a given company

    .DESCRIPTION
    If provided with a valid company name, this function will return the corresponding ConnectWise Manage company id.

    .PARAMETER companyName
    The name of the company as defined in ConnectWise Manage.

    .OUTPUTS
    [int32] ConnectWise Manage company id

    .EXAMPLE
    $companyId = Convert-CwmCompanyNameToId -name "Test Company"

    .NOTES
    #>
    Param(
    
        [Parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$companyName

    )

    $endpoint = "/company/companies?conditions=name=`"$companyName`"&fields=id"
    $result = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString

    return $result.id
}
function Convert-CwmUtcToLocalTime {
    <#
    .SYNOPSIS 
    Generates a DateTime value in local time matching the CWM formatted UTC string passed as a parameter

    .DESCRIPTION
    CWM encodes dates as YYYY-MM-DDTHH:MM:SSZ in UTC. This function converts those strings into DateTime ojects where the time zone is the local time zone

    .PARAMETER CwmDateTimeString
    DateTime string in format YYYY-MM-DDTHH:MM:SSZ

    .OUTPUTS
    DateTime object in local time

    .EXAMPLE
    $cwmDateTime = "2019-04-20T10:06:29Z"
    $locDateTime = Convert-CwmUtcToLocalTime -CwmDateTimeString $cwmDateTime
    This would return a dateTime object with value "Saturday, April 20, 2019 2:06:29 AM" (if you were in Alaska)
    #>
	param
	(
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$CwmDateTimeString
	)

    #remove Z character and replace T with space
    # "2019-04-20T10:06:29Z" -> "2019-04-20 10:06:29"
    $dateTimeStringReformatted = $CwmDateTimeString.replace('T',' ').replace('Z','')

    #get time zones
    $gmt = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "Greenwich Standard Time" }
    $loc = Get-TimeZone

    #retrun converted time
    return [System.TimeZoneInfo]::ConvertTime( $dateTimeStringReformatted , $gmt , $loc )
}
function Convert-DattoSiteToCwmSite {
    <#
    .SYNOPSIS 
    Returns the ConnectWise Manage company and site id for a given Datto RMM site

    .DESCRIPTION
    If provided with a valid Datto RMM site name, this function will return the corresponding ConnectWise Manage company id and site id.

    .PARAMETER siteName
    The name of the company as defined in Datto RMM.

    .OUTPUTS
    [psObject] ConnectWise Manage company id and site id

    .EXAMPLE
    $companyId = Convert-DattoSiteToCwmSite -name "TCX - Test Company"
    $companyId = Convert-DattoSiteToCwmSite -name "TCX - Test Company - Clinic"

    .NOTES
    #>

    Param(
    
        [Parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$siteName

    )

    $cwmInfo = New-Object -TypeName PSObject 
    $hyphenCount = ( $siteName.ToCharArray() | Where-Object { $_ -eq '-' } | Measure-Object ).Count
    if ( $hyphenCount -eq 1 ) {
        $endpoint = "/company/companies?conditions=name=`"$siteName`"&fields=id,site/id"
        $result = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString
        $cwmInfo | Add-Member -MemberType NoteProperty -Value $result.id -Name "companyId" 
        $cwmInfo | Add-Member -MemberType NoteProperty -Value $result.site.id -Name "siteId"
    } elseif ( $hyphenCount -eq 2 ) {
        $firstHyphen = $siteName.IndexOf( " - " );
        $secondHyphen = $siteName.IndexOf( " - " , $firstHyphen + 1 );
        $cn = $siteName.substring( 0 , $secondHyphen )
        $sn = $siteName.substring( $secondHyphen + 3 )
        $endpoint = "/company/companies?conditions=name=`"$cn`"&fields=id"
        $result = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString
        $cwmInfo | Add-Member -MemberType NoteProperty -Value $result.id -Name "companyId"
        if ( $null -eq $cwmInfo.companyId ) {
            Throw ("Could not find a CWM company id for The Datto RMM site name '$siteName'")
        }
        $endpoint = "/company/companies/" + $result.id + "/sites?conditions=name=`"$sn`"&fields=id"
        $result = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $cwmApiUrl -authString $cwmApiAuthString
        $cwmInfo | Add-Member -MemberType NoteProperty -Value $result.id -Name "siteId"
    } else {
        Throw ("The Datto RMM site name '$siteName' is invalid because it has $hyphenCount hyphens")
    }

    if ( $null -eq $cwmInfo.companyId ) {
        Throw ("Could not find a CWM company id for The Datto RMM site name '$siteName'")
    }
    if ( $null -eq $cwmInfo.siteId ) {
        Throw ("Could not find a CWM site id for The Datto RMM site name '$siteName'")
    }
    return $cwmInfo

}
function Convert-LocalTimeToCwmUtc {
    <#
    .SYNOPSIS 
    Generates a CWM formatted UTC string from the DateTime value in local time passed as a parameter

    .DESCRIPTION
    CWM encodes dates as YYYY-MM-DDTHH:MM:SSZ in UTC. This function converts DateTime ojects where the time zone is the local time zone into those strings

    .PARAMETER localDateTime
    DateTime in local time zone

    .OUTPUTS
    DateTime string in format YYYY-MM-DDTHH:MM:SSZ

    .EXAMPLE
    $localDateTime = Get-Date 
    $cwmDateTime = Convert-LocalTimeToCwmUtc -localDateTime $localDateTime
    This would return a dateTime object with value "2019-04-20T10:06:29Z"

    .NOTES
    #>
	param
	(
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [datetime]$localDateTime
	)

    #get time zones
    $gmt = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "Greenwich Standard Time" }
    $loc = Get-TimeZone


    #convert time zone
    $GmtDateTime = [System.TimeZoneInfo]::ConvertTime( $localDateTime.ToString('yyyy-MM-ddTHH:mm:ss') , $loc , $gmt )

    #convert to string in CWM format
    return $GmtDateTime.ToString("yyyy-MM-ddTHH:mm:ssZ")
}
function Get-CwmApiUrl {
    <#
    .SYNOPSIS 
    Gets the Connectwise Manage API url

    .DESCRIPTION
    Connectwise changes their code bases regularly. This function generates an API URL either for a specified code base or returns the most updated
    code base available to your company.

    .PARAMETER apiRegion
    API region. Allowable values are: 
    
    au
    
    eu
    
    na

    .PARAMETER company
    In order to get the most current code base available to you, you must specify your company. This is not needed if specifying codebase.

    .PARAMETER codebase
    To avoid breaking changes as the API develops, you can specify a specific code base (e.g. v4_6_release/). If this is not specified, the function
    will return the URL for the most current code base. This is not needed if specifying company.

    Codebase value must end in a forward slash "/"

    .OUTPUTS
    [string] API URL

    .EXAMPLE
    $apiUrl = Get-CwmApiUrl -apiRegion "na" -company "mycompany"
    This will return the url for the most recent code base in the na region (e.g. "https://api-na.myconnectwise.net/v2019_3/apis/3.0")

    .EXAMPLE
    $apiUrl = Get-CwmApiUrl -apiRegion "na" -codebase "v4_6_release"
    This will return the url for v4_6_release code base in the na region (e.g. "https://api-na.myconnectwise.net/v4_6_release/apis/3.0")

    .NOTES
    #>
	param
	(
        [parameter(Mandatory=$true,ParameterSetName = "Specific code base")]
        [parameter(Mandatory=$true,ParameterSetName = "Most current code base")]
        [ValidateSet("au","eu","na")]
        [string]$apiRegion,

        [parameter(Mandatory=$true,ParameterSetName = "Most current code base")]
        [validateNotNullorEmpty()]
        [string]$company,

        [parameter(Mandatory=$true,ParameterSetName = "Specific code base")]
        [validateNotNullorEmpty()]
        [string]$codebase
    )

    if ( ( $PSBoundParameters.ContainsKey( 'codebase')  ) -eq $false ) {
        $uri = "https://api-" + $apiRegion + ".myconnectwise.net/login/companyinfo/" + $company
        $response = Invoke-WebRequest -uri $uri -UseBasicParsing
        $content = $response.content | ConvertFrom-Json
        $codebase = $content.codebase
    }
    $url = "https://api-$apiRegion.myconnectwise.net/$codebase" + "apis/3.0/"
    return $url
}
function Get-CwmTicket {
    <#
    .SYNOPSIS 
    Gets data for a ConnectWise Manage Ticket

    .DESCRIPTION
    Queries the ConnectWise Manage API for a ticket with a specified Id and returns the data for that ticket.

    .PARAMETER ticketId
    The id (as defined within ConnectWise Manage) of the ticket to get data for

    .PARAMETER apiUrl
    ConnectWise Manage API URL

    .PARAMETER authString
    ConnectWise Manage API authorization string

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .OUTPUTS
    [System.Object] custom object containing ticket data

    .EXAMPLE
    Get-CwmTicket -ticketId 12345678-apiUrl "https://api-na.myconnectwise.net/v2019_4/apis/3.0/" -authString "Basic ZmRqa2VvaXdmaithZHNmYXNkZmFzZmRkZmZpOmZkaWVqZmlkamZpZGZkZmo="

    #>
    Param(
    
        [Parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [int]$ticketId,

        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$apiUrl=$global:cwmApiUrl,
    
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$authString=$global:cwmApiAuthString,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiClientId=$global:cwmApiClientId
    
    )

    if ( $global:cwmApiConfigured -eq $false ) {
        return $null
    }
    try {
        $endpoint = "service/tickets/$ticketId"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId -ErrorAction SilentlyContinue
    } catch {
        $endpoint = "project/tickets/$ticketId"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
    }
    return $ticket
}
function Get-CwmTicketBySummary {
    <#
    .SYNOPSIS 
    Gets data for a ConnectWise Manage Ticket with a specific summary

    .DESCRIPTION
    Queries the ConnectWise Manage API for a ticket with a specified summary and returns the id for that ticket.

    .PARAMETER summary
    The summary of the ticket to get data for

    .PARAMETER apiUrl
    ConnectWise Manage API URL

    .PARAMETER authString
    ConnectWise Manage API authorization string

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .OUTPUTS
    Ticket id (as defined in CWM). ** if more than one ticket is returned, all ids are returned in an array **

    .EXAMPLE
    Get-CwmTicketBySummary -summary "Install patch 12345678 on LAB-004"

    #>
    Param(
    
        [Parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$summary,

        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$apiUrl=$global:cwmApiUrl,
    
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$authString=$global:cwmApiAuthString,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiClientId=$global:cwmApiClientId
    
    )

    $conditions = "summary=`"$summary`""
    $fields = "id"

    try {
        $endpoint = "/service/tickets?conditions=$conditions&fields=$fields"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId -ErrorAction SilentlyContinue
    } catch {
        $endpoint = "/project/tickets?conditions=$conditions&fields=$fields"
        $ticket = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
    }
    #if more than one ticket is returned, all ids are returned in an array
    return $ticket.id
}
function New-CwmApiAuthString {
    <#
    .SYNOPSIS 
    Generates a new connectwise Manage API Access Token

    .DESCRIPTION
    If provided with a valid combination of company id, public key, and private key, this will return a basic auth string for api requests

    The output can be used in headers as:

    $headers = @{ Authorization = $authString }

    .PARAMETER company
    Your company id as defined in ConnectWise Manage

    .PARAMETER publicKey
    Public key for your ConnectWise Manage API access (https://developer.connectwise.com/Products/Manage/Developer_Guide)

    .PARAMETER privateKey
    Private key for your ConnectWise Manage API access (https://developer.connectwise.com/Products/Manage/Developer_Guide)

    .OUTPUTS
    [String] authorization sring

    .EXAMPLE
    $authString = New-CwmApiAuthString -company "mycompany" - publicKey "fjlkdjk" -privateKey "adlsfaffdk"
    This would return a string "Basic a2lqbHUrSTEyMzQ1NjdOTTBwaEpDbjozVmFKbzA5OTk5OTk4ODhG"

    .NOTES
    #>
	param
	(
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$company,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$publicKey,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$privateKey
	)

    # Convert password to secure string
    $user = "$company+$publicKey"
    $pass = $privateKey
    $pair = "${user}:${pass}"

    $bytes = [System.Text.Encoding]::ASCII.GetBytes($pair)
    $base64 = [System.Convert]::ToBase64String($bytes)

    $basicAuthValue = "Basic $base64"

    return $basicAuthValue
}
function New-CwmApiRequest {
    <#
    .SYNOPSIS 
    Performs a query against the Connectwise Manage API

    .DESCRIPTION
    This is a very generic function that performs GET, POST, and PATCH requests to the ConnectWise Manage API. If pageSize is not
    specified in the endpoint parameter, this function will automatically pull the maximum page size (1000) and then loop to pull
    any additional pages, returning all responses combined into a single response object.

    .PARAMETER endpoint
    The ConnectWise Manage API endpoint to hit. This can include additional query data. Endpoint should NOT be URL encoded.

    .PARAMETER apiMethod
    API method (get, post, patch)
    
    .PARAMETER apiRequestBody
    API request body
    
    .PARAMETER apiUrl
    The base ConnectWise Manage API URL

    .PARAMETER authString
    Authorization string to access the ConnectWise Manage API

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .OUTPUTS
    [System.Object] custom object containing API response

    .EXAMPLE
    $tickets = New-CwmApiRequest -endpoint "/service/tickets?conditions=board/id=1 and status/id=505&fields=id,owner/id" -apiMethod "get" -apiUrl "https://api-na.myconnectwise.net/v2019_3/apis/3.0/" -authString "Basic a2lqbHUrSTEyMzQ1NjdOTTBwaEpDbjozVmFKbzA5OTk5OTk4ODhG" 

    .EXAMPLE

    .NOTES
    #>
    [CmdletBinding()]
	param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$endpoint=$null,

        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$apiMethod,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiRequestBody,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiUrl=$global:cwmApiUrl,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$authString=$global:cwmApiAuthString,

        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [string]$apiClientId=$global:cwmApiClientId
    )

    $errorAction = $PSBoundParameters["ErrorAction"]
    if(-not $errorAction){
        $errorAction = $ErrorActionPreference
    }

    #pull maximum records allowable unless endpoint argument already specifies a count
    $escapedEndpoint = [uri]::EscapeUriString( $endpoint )
    #where a client name has & (e.g. RHW - River Health & Wellness) we need need to replace the & with %26 in order to use CW API, 
    #   but cannot replace all & with %26 because & has a function in REST API calls
    $escapedEndpoint = $escapedEndpoint -replace '%20&%20', '%20%26%20'
    $uri = $apiUrl + [uri]::EscapeUriString( $escapedEndpoint )
    if ( $uri.ToLower().IndexOf( "pagesize" ) -eq -1 ) {
        if ( $uri.IndexOf( "?" ) -eq -1 ) {
            $uri += "?pageSize=1000"
        } else {
            $uri += "&pageSize=1000" 
        }
    }

    #set the parameters for the request
    $params = @{
        Uri         =	$uri
        Method      =	$apiMethod
        ContentType	= 	'application/json'
        Headers     =	@{
            'Authorization'	=	$authString
            'clientId' = $apiClientId
        }
    }

    #if body was defined (patch or put), add to params
    if ( $apiRequestBody ) {
        $params.Add( 'Body' , $apiRequestBody )
    }

    #make api request
    try { $response = ( Invoke-WebRequest @params -UseBasicParsing ) | Select-Object StatusCode,Content,Headers }
    catch {
        if ( $errorAction.ToString().ToLower() -ne "silentlycontinue") {
            Write-Log -message "API Request failed`n$PSItem" -entryType "Error"
        }
        throw
    }

    $content = $response.content | ConvertFrom-Json
    if ( ( $null -eq $response.Headers['Link'] ) -or ( $response.Headers['Link'].IndexOf( 'rel="next"' ) -eq -1 ) ) {
        return $content
    } else {
        #extract 'next' url from a string like
        #<https://api-na.myconnectwise.net/v4_6_release/apis/3.0/service/tickets/?pageSize=1000&page=2>; rel="next", <https://api-na.myconnectwise.net/v4_6_release/apis/3.0/service/tickets/?pageSize=1000&page=230>; rel="last"
        $linkInfo = $response.Headers['Link']
        $linkInfo = $linkInfo.Replace('rel=','').Replace('<','').Replace('>','').Replace('"','').Replace(' ','')
        $linkInfo = $linkInfo.Split(',')
        foreach ( $link in $linkInfo ) {
            $info = $link.split(';')
            if ( $info[1] -eq 'next') {
                $nextUrl = $info[0]
            }
        }
        $params = @{
            "apiUrl" = $nextUrl
            "authString" = $cwmApiAuthString
            "apiMethod" = $apiMethod
        }
        if ( $apiRequestBody ) {
            $params.Add( 'Body' , $apiRequestBody )
        }
        $restOfContent = New-CwmApiRequest @params
        return $content + $restOfContent
    }
}
function New-CwmTicket {
    <#
    .SYNOPSIS 
    Creates a new ConnectWise Manage ticket

    .DESCRIPTION
    Creates a new ConnectWise Manage ticket on the default board with the default source for the given comand the supplied 

    .PARAMETER summary
    Summary for the new ticket

    .PARAMETER initialDescription
    Text for the initial description

    .PARAMETER priority
    Ticket priority id (defaults to 8, which is "medium")

    .PARAMETER projectId
    Project id to which to attach ticket

    .PARAMETER phaseDescription
    Phase to which to attach ticket

    .PARAMETER apiUrl
    The base ConnectWise Manage API URL

    .PARAMETER authString
    Authorization string to access the ConnectWise Manage API

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .OUTPUTS
    [int32] ticket id

    .EXAMPLE
    $ticketId = New-CwmTicket -summary "test ticket" -initialDescription "this is a test" -apiUrl "https://api-na.myconnectwise.net/v2019_3/apis/3.0/" -authString "Basic a2lqbHUrSTEyMzQ1NjdOTTBwaEpDbjozVmFKbzA5OTk5OTk4ODhG"  

    .EXAMPLE
    $ticketId = New-CwmTicket -summary "test ticket" -initialDescription "this is a test" -projectId 33 -phaseDescription "Test Phase" -apiUrl "https://api-na.myconnectwise.net/v2019_3/apis/3.0/" -authString "Basic a2lqbHUrSTEyMzQ1NjdOTTBwaEpDbjozVmFKbzA5OTk5OTk4ODhG"  

    .NOTES
    #>
    Param(
    
        [parameter(Mandatory=$true,ParameterSetName = "Create a service ticket")]
        [parameter(Mandatory=$true,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [string]$summary,

        [parameter(Mandatory=$true,ParameterSetName = "Create a service ticket")]
        [parameter(Mandatory=$true,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [string]$initialDescription,
        
        [parameter(Mandatory=$false,ParameterSetName = "Create a service ticket")]
        [ValidateSet("6","15","8","7","12")]
        [int]$priority = 8,
        # 6-Critical 15-high 8-medium 7-low 12-do not respond

        [parameter(Mandatory=$true,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [int]$projectId,

        [parameter(Mandatory=$true,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [string]$phaseDescription,

        [parameter(Mandatory=$false,ParameterSetName = "Create a service ticket")]
        [parameter(Mandatory=$false,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [string]$apiUrl=$global:cwmApiUrl,

        [parameter(Mandatory=$false,ParameterSetName = "Create a service ticket")]
        [parameter(Mandatory=$false,ParameterSetName = "Create a project ticket")]
        [validateNotNullOrEmpty()]
        [string]$authString=$global:cwmApiAuthString,

        [parameter(Mandatory=$false,ParameterSetName = "Create a service ticket")]
        [parameter(Mandatory=$false,ParameterSetName = "Create a project ticket")]
        [validateNotNullorEmpty()]
        [string]$apiClientId=$global:cwmApiClientId
    )

    if ( ( $PSBoundParameters.ContainsKey( 'projectId')  ) -eq $true ) {
        $endpoint = "project/projects/$projectId/phases?conditions=description=`"$phaseDescription`"&fields=id"
        $phase = New-CwmApiRequest -endpoint $endpoint -apiMethod "get" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
        $body = @{
            summary = $summary
            initialDescription = $initialDescription
            phase = @{ id = $phase.id }
        } | ConvertTo-Json
        $ticket = New-CwmApiRequest -endpoint "project/tickets" -apiRequestBody $body -apiMethod "post" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
    } else {
        $cwmSiteInfo = Convert-DattoSiteToCwmSite( $Env:CS_PROFILE_NAME )
        $body = @{
            summary = $summary
            initialDescription = $initialDescription
            company = @{ id = $cwmSiteInfo.companyId }
            site = @{ id = $cwmSiteInfo.siteId }
            priority = @{ id = $priority }
        } | ConvertTo-Json
        $ticket = New-CwmApiRequest -endpoint "service/tickets" -apiRequestBody $body -apiMethod "post" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
    }

    return $ticket.id

}
function New-CwmTicketNote {
    <#
    .SYNOPSIS 
    Creates a new ConnectWise Manage ticket note

    .DESCRIPTION
    Creates a new ConnectWise Manage ticket note for either a project or a service ticket

    .PARAMETER ticketId
    Id for ticket to which to add a note.

    .PARAMETER text
    Note text
    
    .PARAMETER detailDescription
    Indicates that note should be flagged as "discussion"

    .PARAMETER internalAnalysis
    Indicates that note should be flagged as "internal"

    .PARAMETER resolution
    Indicates that note should be flagged as "resolution"

    .PARAMETER apiUrl
    The base ConnectWise Manage API URL

    .PARAMETER authString
    Authorization string to access the ConnectWise Manage API

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration
    
    .NOTES
    #>
    Param(
    
    [Parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [int]$ticketId,

    [parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [string]$text,

    [parameter()]
    [switch]$detailDescription,

    [parameter()]
    [switch]$internalAnalysis,

    [parameter()]
    [switch]$resolution,

    [parameter(Mandatory=$false)]
    [validateNotNullOrEmpty()]
    [string]$apiUrl=$global:cwmApiUrl,

    [parameter(Mandatory=$false)]
    [validateNotNullOrEmpty()]
    [string]$authString=$global:cwmApiAuthString,

    [parameter(Mandatory=$false)]
    [validateNotNullorEmpty()]
    [string]$apiClientId=$global:cwmApiClientId

    )

    if ( $global:cwmApiConfigured -eq $false ) {
        return $null
    }
    if ( -not ( $detailDescription.IsPresent -or $internalAnalysis.IsPresent -or $resolution.IsPresent ) ) {
        Throw ("There was an attempt to create a ticket note without choosing a flag (discussion, internal, resolution). At least one must be selected.")
    }

    $ticket = Get-CwmTicket -ticketId $ticketId -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId -ErrorAction SilentlyContinue
    if ( $ticket.board.id -eq $cwmProjectBoardId ) {
        $endpoint = "project/tickets/$ticketId/notes"
    } else {
        $endpoint = "service/tickets/$ticketId/notes"
    }

    $body = @{
        ticketid = $ticketId
        detailDescriptionFlag = $detailDescription.IsPresent
        internalAnalysisFlag = $internalAnalysis.IsPresent
        resolutionFlag = $resolution.IsPresent
        processNotifications = $false
        text = $text
    } | ConvertTo-Json

    New-CwmApiRequest -endpoint $endpoint -apiRequestBody $body -apiMethod "post" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
}
function New-CwmTimeEntry {
    <#
    .SYNOPSIS 
    Creates a new ConnectWise Manage time entry

    .DESCRIPTION
    Creates a new ConnectWise Manage ticket on the default board with the default source for the given comand the supplied 

    .PARAMETER ticketId
    Id for ticket to which to add time.

    .PARAMETER timeStart
    DateTime value indicating when work began.

    .PARAMETER timeEnd
    DateTime value indicating when work ended. If $timeEnd -le $timeStart, then $timeEnd will be set to $timeStart + 1 minute.

    .PARAMETER notes
    Notes to include in time entry.

    .PARAMETER workRoleId
    Work role id to apply

    .PARAMETER apiUrl
    The base ConnectWise Manage API URL

    .PARAMETER authString
    Authorization string to access the ConnectWise Manage API

    .PARAMETER apiClientId
    Unique GUID or Globally Unique Identifier assigned to each ConnectWise integration

    .NOTES
    #>
    Param(
    
    [Parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [int]$ticketId,

    [parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [DateTime]$timeStart,

    [parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [DateTime]$timeEnd,

    [parameter(Mandatory=$true)]
    [validateNotNullOrEmpty()]
    [string]$notes,

    [parameter(Mandatory=$false)]
    [validateNotNullOrEmpty()]
    [string]$workRoleId=$global:cwmWorkRoleId,

    [parameter(Mandatory=$false)]
    [validateNotNullOrEmpty()]
    [string]$apiUrl=$global:cwmApiUrl,

    [parameter(Mandatory=$false)]
    [validateNotNullOrEmpty()]
    [string]$authString=$global:cwmApiAuthString,

    [parameter(Mandatory=$false)]
    [validateNotNullorEmpty()]
    [string]$apiClientId=$global:cwmApiClientId

    )

    if ( $global:cwmApiConfigured -eq $false ) {
        return $null
    }
    $minutes = $timeEnd.Subtract($timeStart).Minutes

    if ( $minutes -lt 1 ) {
        $timeEnd = $timeStart.AddMinutes(1)
    }

    $ticket = Get-CwmTicket -ticketId $ticketId -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId -ErrorAction SilentlyContinue
    if ( $ticket.board.id -eq $cwmProjectBoardId ) {
        $endpoint = "project/tickets/$ticketId"
        $chargeToType = "ProjectTicket"
        $timeAllowedStatus = $global:cwmProjectTicketTimeAllowedStatus
        $openStatus = $cwmProjectTicketStatusOpen
    } else {
        $endpoint = "service/tickets/$ticketId"
        $chargeToType = "ServiceTicket"
        $timeAllowedStatus = $global:cwmServiceTicketTimeAllowedStatus
        $openStatus = $cwmServiceTicketStatusOpen
    }
    #check whether ticket is in a time-entry allowed status
    if ( $timeAllowedStatus -notcontains $ticket.status.id ) {
        $body = @{
            op = "replace"
            path = "status"
            value = @{ id = $openStatus }
        } | ConvertTo-Json
        $body = "[$body]"
        New-CwmApiRequest -endpoint $endpoint -apiRequestBody $body -apiMethod "patch" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
    }

    $body = @{
        chargeToId = $ticketId
        chargeToType = $chargeToType
        member = @{ id = $cwmMemberId }
        workRole = @{ id = $workRoleId }
        timeStart = Convert-LocalTimeToCwmUtc -localDateTime $timeStart
        timeEnd = Convert-LocalTimeToCwmUtc -localDateTime  $timeEnd
        notes = $notes
    } | ConvertTo-Json
 
    New-CwmApiRequest -endpoint "time/entries" -apiRequestBody $body -apiMethod "post" -apiUrl $apiUrl -authString $authString -apiClientId $apiClientId
}
function New-CryptographyKey()
{
<#
.SYNOPSIS 
Generates a random cryptography key.

.DESCRIPTION
Generates a random cryptography key based on the desired key size.

.PARAMETER Algorithm
Algorithm to generate key for.

.PARAMETER KeySize
Number of bits the generated key will have.

.PARAMETER AsPlainText
Returns a String instead of SecureString.

.OUTPUTS
System.Security.SecureString. New-CryptographyKey return the key as a SecureString by default.
System.String. New-CryptographyKey will return the key in plain text as a string if the -AsPlainText parameter is specified.

.EXAMPLE
$key = New-CryptographyKey
This example generates a random 256-bit AES key and stores it in the variable $key.

.NOTES
Author: Tyler Siegrist
Date: 9/22/2017
Downloaded from https://gallery.technet.microsoft.com/scriptcenter/EncryptDecrypt-files-use-65e7ae5d on 3/8/2019

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

#>
[CmdletBinding()]
[OutputType([System.Security.SecureString])]
[OutputType([String], ParameterSetName='PlainText')]
Param(
    [Parameter(Mandatory=$false, Position=1)]
    [ValidateSet('AES','DES','RC2','Rijndael','TripleDES')]
    [String]$Algorithm='AES',
    [Parameter(Mandatory=$false, Position=2)]
    [Int]$KeySize,
    [Parameter(ParameterSetName='PlainText')]
    [Switch]$AsPlainText
)
    Process
    {
        try
        {
            $Crypto = [System.Security.Cryptography.SymmetricAlgorithm]::Create($Algorithm)
            if($PSBoundParameters.ContainsKey('KeySize')){
                $Crypto.KeySize = $KeySize
            }
            $Crypto.GenerateKey()
            if($AsPlainText)
            {
                return [System.Convert]::ToBase64String($Crypto.Key)
            }
            else
            {
                return [System.Convert]::ToBase64String($Crypto.Key) | ConvertTo-SecureString -AsPlainText -Force
            }
        }
        catch
        {
            Write-Error $_
        }
        
    }
}
Function Protect-File
{
<#
.SYNOPSIS 
Encrypts a file using a symmetrical algorithm.

.DESCRIPTION
Encrypts a file using a symmetrical algorithm.

.PARAMETER FileName
File(s) to be encrypted.

.PARAMETER Key
Cryptography key as a SecureString to be used for encryption.

.PARAMETER KeyAsPlainText
Cryptography key as a String to be used for encryption.

.PARAMETER CipherMode
Specifies the block cipher mode to use for encryption.

.PARAMETER PaddingMode
Specifies the type of padding to apply when the message data block is shorter than the full number of bytes needed for a cryptographic operation.

.PARAMETER Suffix
Suffix of the encrypted file to be removed.

.PARAMETER RemoveSource
Removes the source (decrypted) file after encrypting.

.OUTPUTS
System.IO.FileInfo. Protect-File will return FileInfo with the SourceFile, Algorithm, Key, CipherMode, and PaddingMode as added NoteProperties

.EXAMPLE
Protect-File 'C:\secrets.txt' $key
This example encrypts C:\secrets.txt using the key stored in the variable $key. The encrypted file would have the default extension of '.AES' and the source (decrypted) file would not be removed.

.EXAMPLE
Protect-File 'C:\secrets.txt' -Algorithm DES -Suffix '.Encrypted' -RemoveSource
This example encrypts C:\secrets.txt with a randomly generated DES key. The encrypted file would have an extension of '.Encrypted' and the source (decrypted) file would be removed.

.EXAMPLE
Get-ChildItem 'C:\Files' -Recurse | Protect-File -Algorithm AES -Key $key -RemoveSource
This example encrypts all of the files under the C:\Files directory using the key stored in the variable $key. The encrypted files would have the default extension of '.AES' and the source (decrypted) files would be removed.

.NOTES
Author: Tyler Siegrist
Date: 9/22/2017
Downloaded from https://gallery.technet.microsoft.com/scriptcenter/EncryptDecrypt-files-use-65e7ae5d on 3/8/2019

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

#>
[CmdletBinding(DefaultParameterSetName='SecureString')]
[OutputType([System.IO.FileInfo[]])]
Param(
    [Parameter(Mandatory=$true, Position=1, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
    [Alias('PSPath','LiteralPath')]
    [string[]]$FileName,
    [Parameter(Mandatory=$false, Position=2)]
    [ValidateSet('AES','DES','RC2','Rijndael','TripleDES')]
    [String]$Algorithm = 'AES',
    [Parameter(Mandatory=$false, Position=3, ParameterSetName='SecureString')]
    [System.Security.SecureString]$Key = (New-CryptographyKey -Algorithm $Algorithm),
    [Parameter(Mandatory=$true, Position=3, ParameterSetName='PlainText')]
    [String]$KeyAsPlainText,
    [Parameter(Mandatory=$false, Position=4)]
    [System.Security.Cryptography.CipherMode]$CipherMode,
    [Parameter(Mandatory=$false, Position=5)]
    [System.Security.Cryptography.PaddingMode]$PaddingMode,
    [Parameter(Mandatory=$false, Position=6)]
    [String]$Suffix = ".$Algorithm",
    [Parameter()]
    [Switch]$RemoveSource
)
    Begin
    {
        #Configure cryptography
        try
        {
            if($PSCmdlet.ParameterSetName -eq 'PlainText')
            {
                $Key = $KeyAsPlainText | ConvertTo-SecureString -AsPlainText -Force
            }

            #Decrypt cryptography Key from SecureString
            $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Key)
            $EncryptionKey = [System.Convert]::FromBase64String([System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR))

            $Crypto = [System.Security.Cryptography.SymmetricAlgorithm]::Create($Algorithm)
            if($PSBoundParameters.ContainsKey('CipherMode')){
                $Crypto.Mode = $CipherMode
            }
            if($PSBoundParameters.ContainsKey('PaddingMode')){
                $Crypto.Padding = $PaddingMode
            }
            $Crypto.KeySize = $EncryptionKey.Length*8
            $Crypto.Key = $EncryptionKey
        }
        Catch
        {
            Write-Error $_ -ErrorAction Stop
        }
    }
    Process
    {
        $Files = Get-Item -LiteralPath $FileName
    
        ForEach($File in $Files)
        {
            $DestinationFile = $File.FullName + $Suffix

            Try
            {
                $FileStreamReader = New-Object System.IO.FileStream($File.FullName, [System.IO.FileMode]::Open)
                $FileStreamWriter = New-Object System.IO.FileStream($DestinationFile, [System.IO.FileMode]::Create)

                #Write IV (initialization-vector) length & IV to encrypted file
                $Crypto.GenerateIV()
                $FileStreamWriter.Write([System.BitConverter]::GetBytes($Crypto.IV.Length), 0, 4)
                $FileStreamWriter.Write($Crypto.IV, 0, $Crypto.IV.Length)

                #Perform encryption
                $Transform = $Crypto.CreateEncryptor()
                $CryptoStream = New-Object System.Security.Cryptography.CryptoStream($FileStreamWriter, $Transform, [System.Security.Cryptography.CryptoStreamMode]::Write)
                $FileStreamReader.CopyTo($CryptoStream)
    
                #Close open files
                $CryptoStream.FlushFinalBlock()
                $CryptoStream.Close()
                $FileStreamReader.Close()
                $FileStreamWriter.Close()

                #Delete unencrypted file
                if($RemoveSource){Remove-Item -LiteralPath $File.FullName}

                #Output ecrypted file
                $result = Get-Item $DestinationFile
                $result | Add-Member �MemberType NoteProperty �Name SourceFile �Value $File.FullName
                $result | Add-Member �MemberType NoteProperty �Name Algorithm �Value $Algorithm
                $result | Add-Member �MemberType NoteProperty �Name Key �Value $Key
                $result | Add-Member �MemberType NoteProperty �Name CipherMode �Value $Crypto.Mode
                $result | Add-Member �MemberType NoteProperty �Name PaddingMode �Value $Crypto.Padding
                $result
            }
            Catch
            {
                Write-Error $_
                If($FileStreamWriter)
                {
                    #Remove failed file
                    $FileStreamWriter.Close()
                    Remove-Item -LiteralPath $DestinationFile -Force
                }
                Continue
            }
            Finally
            {
                if($CryptoStream){$CryptoStream.Close()}
                if($FileStreamReader){$FileStreamReader.Close()}
                if($FileStreamWriter){$FileStreamWriter.Close()}
            }
        }
    }
}
Function Unprotect-File
{
<#
.SYNOPSIS 
Decrypts a file encrypted with Protect-File.

.DESCRIPTION
Decrypts a file using a provided cryptography key.

.PARAMETER FileName
File(s) to be decrypted.

.PARAMETER Key
Cryptography key as a SecureString be used for decryption.

.PARAMETER KeyAsPlainText
Cryptography key as a String to be used for decryption.

.PARAMETER CipherMode
Specifies the block cipher mode that was used for encryption.

.PARAMETER PaddingMode
Specifies the type of padding that was applied when the message data block was shorter than the full number of bytes needed for a cryptographic operation.

.PARAMETER Suffix
Suffix of the encrypted file to be removed.

.PARAMETER RemoveSource
Removes the source (encrypted) file after decrypting.

.OUTPUTS
System.IO.FileInfo. Unprotect-File will return FileInfo with the SourceFile as an added NoteProperty

.EXAMPLE
Unprotect-File 'C:\secrets.txt.AES' $key
This example decrypts C:\secrets.txt.AES using the key stored in the variable $key. The decrypted file would remove the default extension of '.AES' and the source (encrypted) file would not be removed.

.EXAMPLE
Unprotect-File 'C:\secrets.txt.Encrypted' -Algorithm DES -Key $key -Suffix '.Encrypted' -RemoveSource
This example decrypts C:\secrets.txt.Encrypted using DES and the key stored in the variable $key. The decrypted file would remove the extension of '.Encrypted' and the source (encrypted) file would be removed.

.EXAMPLE
Get-ChildItem 'C:\Files' -Recurse | Unprotect-File -Algorithm AES -Key $key -RemoveSource
This example decrypts all of the files under the C:\Files directory using the key stored in the variable $key. The decrypted files would remove the default extension of '.AES' and the source (encrypted) files would be removed.

.NOTES
Author: Tyler Siegrist
Date: 9/22/2017
Downloaded from https://gallery.technet.microsoft.com/scriptcenter/EncryptDecrypt-files-use-65e7ae5d on 3/8/2019

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

#>
[CmdletBinding(DefaultParameterSetName='SecureString')]
[OutputType([System.IO.FileInfo[]])]
Param(
    [Parameter(Mandatory=$true, Position=1, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
    [Alias('PSPath','LiteralPath')]
    [string[]]$FileName,
    [Parameter(Mandatory=$false, Position=2, ValueFromPipelineByPropertyName=$true)]
    [ValidateSet('AES','DES','RC2','Rijndael','TripleDES')]
    [String]$Algorithm = 'AES',
    [Parameter(Mandatory=$true, Position=3, ValueFromPipelineByPropertyName=$true, ParameterSetName='SecureString')]
    [System.Security.SecureString]$Key,
    [Parameter(Mandatory=$true, Position=3, ParameterSetName='PlainText')]
    [String]$KeyAsPlainText,
    [Parameter(Mandatory=$false, Position=4, ValueFromPipelineByPropertyName=$true)]
    [System.Security.Cryptography.CipherMode]$CipherMode = 'CBC',
    [Parameter(Mandatory=$false, Position=5, ValueFromPipelineByPropertyName=$true)]
    [System.Security.Cryptography.PaddingMode]$PaddingMode = 'PKCS7',
    [Parameter(Mandatory=$false, Position=6)]
    [String]$Suffix, #Assigning default value in code due to it not processing ".$Algorithm" properly when Algorithm is ValueFromPipelineByPropertyName
    [Parameter()]
    [Switch]$RemoveSource
)
    Process
    {
        #Configure cryptography
        try
        {
            if($PSCmdlet.ParameterSetName -eq 'PlainText')
            {
                $Key = $KeyAsPlainText | ConvertTo-SecureString -AsPlainText -Force
            }

            #Decrypt cryptography Key from SecureString
            $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Key)
            $EncryptionKey = [System.Convert]::FromBase64String([System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR))

            $Crypto = [System.Security.Cryptography.SymmetricAlgorithm]::Create($Algorithm)
            $Crypto.Mode = $CipherMode
            $Crypto.Padding = $PaddingMode
            $Crypto.KeySize = $EncryptionKey.Length*8
            $Crypto.Key = $EncryptionKey
        }
        Catch
        {
            Write-Error $_ -ErrorAction Stop
        }

        if(-not $PSBoundParameters.ContainsKey('Suffix'))
        {
            $Suffix = ".$Algorithm"
        }

        #Used to store successfully decrypted file names.
        $Files = Get-Item -LiteralPath $FileName

        ForEach($File in $Files)
        {
            #Verify file ends with supplied suffix
            If(-not $File.Name.EndsWith($Suffix))
            {
                Write-Error "$($File.FullName) does not have an extension of '$Suffix'."
                Continue
            }

            $DestinationFile = $File.FullName -replace "$Suffix$"

            Try
            {
                $FileStreamReader = New-Object System.IO.FileStream($File.FullName, [System.IO.FileMode]::Open)
                $FileStreamWriter = New-Object System.IO.FileStream($DestinationFile, [System.IO.FileMode]::Create)

                #Get IV from file
                [Byte[]]$LenIV = New-Object Byte[] 4
                $FileStreamReader.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
                $FileStreamReader.Read($LenIV,  0, 3) | Out-Null
                [Int]$LIV = [System.BitConverter]::ToInt32($LenIV,  0)
                [Byte[]]$IV = New-Object Byte[] $LIV
                $FileStreamReader.Seek(4, [System.IO.SeekOrigin]::Begin) | Out-Null
                $FileStreamReader.Read($IV, 0, $LIV) | Out-Null
                $Crypto.IV = $IV

                #Peform Decryption
                $Transform = $Crypto.CreateDecryptor()
                $CryptoStream = New-Object System.Security.Cryptography.CryptoStream($FileStreamWriter, $Transform, [System.Security.Cryptography.CryptoStreamMode]::Write)
                $FileStreamReader.CopyTo($CryptoStream)

                #Close open files
                $CryptoStream.FlushFinalBlock()
                $CryptoStream.Close()
                $FileStreamReader.Close()
                $FileStreamWriter.Close()

                #Delete encrypted file
                if($RemoveSource){Remove-Item $File.FullName}

                #Output decrypted file
                Get-Item $DestinationFile | Add-Member �MemberType NoteProperty �Name SourceFile �Value $File.FullName -PassThru
            }
            Catch
            {
                Write-Error $_
                If($FileStreamWriter)
                {
                    #Remove failed file
                    $FileStreamWriter.Close()
                    Remove-Item -LiteralPath $DestinationFile -Force
                }
                Continue
            }
            Finally
            {
                if($CryptoStream){$CryptoStream.Close()}
                if($FileStreamReader){$FileStreamReader.Close()}
                if($FileStreamWriter){$FileStreamWriter.Close()}
            }
        }
    }
}
function Confirm-HubConfiguration {
    <#
    .SYNOPSIS 
    Checks whether the needed variables have been defined in the Datto settings screen
    
    .DESCRIPTION
    Checks whether the needed variables have been defined in the Datto settings screen

    .EXAMPLE
    Confirm-HubConfiguration

    .OUTPUTS
    [Boolean]

    #>

    $confirmed = $true

    #datto api settings
    if (    $null -ne $env:dattoRmmApiUrl `
       -and $null -ne $env:dattoRmmAccessKey `
       -and $null -ne $env:dattoRmmSecretKey `
    ) {
        $global:dattoRMMApiConfigured = $true
    } else {
        Write-Host "Not all Datto RMM API variables were defined. Deactivating Datto RMM Api integration."
        $global:dattoRMMApiConfigured = $false
    }

    if ( $global:dattoRMMApiConfigured ) {
        if ( ( $null -eq $dattoRmmApiUrl -as [System.URI]).AbsoluteURI ) {
            Write-Error "value for dattoRmmApiUrl is invalid"
        }
        if ( $env:dattoRmmAccessKey -cnotmatch "^[0-9A-Z]{32}$" ) {
            Write-Error "value for DattoRmmAccessKey is invalid"
            $confirmed = $false
        }
        if ( $env:dattoRmmSecretKey -cnotmatch "^[0-9A-Z]{32}$" ) {
            Write-Error "value for dattoRmmSecretKey is invalid"
            $confirmed = $false
        }
    }

    #cwm api settings
    if (    $null -ne $env:cwmApiClientId `
       -and $null -ne $env:cwmApiPublicKey `
       -and $null -ne $env:cwmApiPrivateKey `
       -and $null -ne $env:cwmServiceBoardId `
       -and $null -ne $env:cwmProjectBoardId `
       -and $null -ne $env:cwmServiceTicketStatusClosed `
       -and $null -ne $env:cwmServiceTicketStatusOpen `
       -and $null -ne $env:cwmServiceTicketTimeAllowedStatus `
       -and $null -ne $env:cwmProjectTicketStatusClosed `
       -and $null -ne $env:cwmProjectTicketStatusOpen `
       -and $null -ne $env:cwmProjectTicketTimeAllowedStatus `
       -and $null -ne $env:cwmMemberId `
       -and $null -ne $env:cwmWorkRoleId `
    ) {
        $global:cwmApiConfigured = $true
    } else {
        Write-Host "Not all Connectwise Manage variables were defined. Deactivating Connectwise Manage integration."
        $global:cwmApiConfigured = $false
    }

    if ( $global:cwmApiConfigured ) {
        if ( $env:cwmCompany -inotmatch "^[0-9A-Z]{1,}$" ) {
            Write-Error "value for cwmCompany is invalid"
            $confirmed = $false
        }
        if ( $env:cwmApiRegion -inotmatch "^[0-9A-Z]{2}$" ) {
            Write-Error "value for cwmCompany is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmApiClientId -inotmatch "^[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}$" ) {
            Write-Error "value for cwmApiClientId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmApiPublicKey -inotmatch "^[0-9A-Z]{16}$" ) {
            Write-Error "value for cwmApiPublicKey is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmApiPrivateKey -inotmatch "^[0-9A-Z]{16}$" ) {
            Write-Error "value for cwmApiPrivateKey is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmServiceBoardId -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmServiceBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmProjectBoardId -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmServiceTicketStatusClosed -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmServiceTicketStatusOpen -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmProjectTicketStatusClosed -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmProjectTicketStatusOpen -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmMemberId -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
        if ( $env:cwmWorkRoleId -inotmatch "^\d{1,}$" ) {
            Write-Error "value for cwmProjectBoardId is invalid"
            $confirmed = $false
        } 
    }

    #office365 settings
    if (    $null -ne $env:o365Account `
       -and $null -ne $env:o365Password `
       -and $null -ne $env:msTeamsWebhook1 `
       -and $null -ne $env:msTeamsWebhook2 `
    ) {
        $global:o365Configured = $true
    } else {
        Write-Host "Not all Office 365 variables were defined. Deactivating Office 365 integration."
        $global:o365Configured = $false
    }
 
    if ( $global:o365Configured ) {
        if ( $env:msTeamsWebhook1 -inotmatch "^[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}@[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}$" ) {
            Write-Error "value for msTeamsWebhook1 is invalid"
            $confirmed = $false
        } 
        if ( $env:msTeamsWebhook2 -inotmatch "^[0-9A-Z]{32}\/[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}$" ) {
            Write-Error "value for msTeamsWebhook2 is invalid"
            $confirmed = $false
        } 
    }


    #dell api settings
    if (    $null -ne $env:dellWarrantyApiClientId `
       -and $null -ne $env:dellWarrantyApiClientSecret `
    ) {
        $global:dellWarrantyApiConfigured = $true
    } else {
        $global:dellWarrantyApiConfigured = $false
    }

    return $confirmed

}
function Get-CustomUdf {
    <#
    .SYNOPSIS 
    Gets a custom udf value for the current device

    .PARAMETER udf
    Custom udf to get value of (1-30)

    .OUTPUTS
    [String] udf value

    .EXAMPLE
    $value = Get-CustomUdf 26

    .NOTES
    #>

    Param(
    
    [Parameter(Mandatory=$true,Position=0)]
    [validateNotNullOrEmpty()]
    [int]$udf

    )

    $value = Get-ChildItem -Path Env:* | Where-Object { $_.Name.ToLower() -eq "udf_$udf" } | Select-Object -ExpandProperty Value
    return $value
}
function Get-DeviceId {
    <#
    .SYNOPSIS 
    Gets current device's Datto RMM Id

    .DESCRIPTION
    Datto RMM assigns each device a unique id in the form "53c59385-f94w-43j8-583v-8wec83c93853". This function returns the id 
    of the device on which it is run.

    .OUTPUTS
    [String] device id

    .EXAMPLE
    $deviceId = Get-DeviceId

    .NOTES
    #>
    $deviceId = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\CentraStage' -Name DeviceId).DeviceId
    return $deviceId
}
function Get-DomainCredential {
    <#
    .SYNOPSIS 
    Gets domain credentials

    .DESCRIPTION
    Gets domain credentials stored in Datto RMM site UDFs

    .EXAMPLE
    Get-DomainCredentials
    #>
    
    $password = $env:domainAdminPw
    $userName = $env:domainAdminUn
    
    if ( $null -eq $password -or $null -eq $userName ) {
        Throw ("Could not find a domain username or password in Datto RMM site variables")
    }
    $passwordSecureString = ConvertTo-SecureString $password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential ( $userName , $passwordSecureString )
    return $credential
}
function Set-CustomUdf {
    <#
    .SYNOPSIS 
    Writes a value to a Datto RMM Custom UDF

    .DESCRIPTION
    Writes a specified value to a specified Datto RMM Custom UDF via the registry

    .PARAMETER Udf
    UDF to write to (1-30)

    .PARAMETER Value
    Value to write

    .EXAMPLE
    Set-CustomUdf -customUdf 22 -value 'Complete'
    #>
    param (
        [parameter(Mandatory=$true)]
        [ValidateRange(1,30)]
        [int32]$udf,
        
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]
        $Value
    )

    Set-ItemProperty -Path HKLM:\SOFTWARE\CentraStage -Name Custom$udf  -Value $Value

}
function Set-HubConfiguration {
    <#
    .SYNOPSIS 
    Creates global variables for use in hub derived from environment variables defined in DattoRMM
    
    .DESCRIPTION
    Creates global variables for use in hub derived from environment variables defined in DattoRMM

    .EXAMPLE
    Set-HubConfiguration

    #>

if ( Confirm-HubConfiguration ) {
    $global:hubFunctionsConfigImported = $true

    if ( $global:dattoRMMApiConfigured ) {
        $global:dattoRmmApiAccessToken = New-DattoRmmApiAccessToken -apiUrl $env:dattoRmmApiUrl -accessKey $env:dattoRmmAccessKey -secretKey $env:dattoRmmSecretKey
        $global:dattoRmmApiUrl = $env:dattoRmmApiUrl
        Write-Log -Message "Datto RMM API integration configured" -EntryType "Information"
    }
    
    if ( $global:cwmApiConfigured ) {
        $global:cwmApiUrl = Get-CwmApiUrl -apiRegion $env:cwmApiRegion -company $env:cwmCompany
        $global:cwmApiAuthString = New-CwmApiAuthString -company $env:cwmCompany -publicKey $env:cwmApiPublicKey -privateKey $env:cwmApiPrivateKey
        $global:cwmApiClientId = $env:cwmApiClientId
        $global:cwmServiceBoardId = $env:cwmServiceBoardId
        $global:cwmProjectBoardId = $env:cwmProjectBoardId
        $global:cwmServiceTicketStatusClosed = $env:cwmServiceTicketStatusClosed
        $global:cwmProjectTicketStatusClosed = $env:cwmProjectTicketStatusClosed
        $global:cwmServiceTicketStatusOpen = $env:cwmServiceTicketStatusOpen
        $global:cwmProjectTicketStatusOpen = $env:cwmProjectTicketStatusOpen
        $global:cwmServiceTicketTimeAllowedStatus = $env:cwmServiceTicketTimeAllowedStatus
        $global:cwmProjectTicketTimeAllowedStatus = $env:cwmProjectTicketTimeAllowedStatus
        $global:cwmMemberId = $env:cwmMemberId
        $global:cwmWorkRoleId = $env:cwmWorkRoleId
        $global:cwmApiConfigured = $true
        Write-Log -Message "Connectwise Manage integration configured" -EntryType "Information"
    }
    
    if ( $global:o365Configured ) {
        $o365PasswordSecure = ConvertTo-SecureString $env:o365Password -AsPlainText -Force
        $o365Credential = New-Object System.Management.Automation.PSCredential( $env:o365Account , $o365PasswordSecure )
        $global:o365Account = $env:o365Account
        $global:o365AccountCredential = $o365Credential
        $global:msTeamsWebhook = "https://outlook.office.com/webhook/$env:msTeamsWebhook1/IncomingWebhook/$env:msTeamsWebhook2"
        Write-Log -Message "Office365 integration configured" -EntryType "Information"
    }

    if ( $global:dellWarrantyApiConfigured ) {
        $global:dellWarrantyApiToken = Get-DellWarrantyApiToken -clientId $env:dellWarrantyApiClientId -clientSecret $env:dellWarrantyApiClientSecret
        Write-Log -Message "Dell Warranty API integration configured" -EntryType "Information"
    }
}

}
function Get-DeviceData {
    <#
    .SYNOPSIS 
    Gets device data from the Datto RMM API

    .DESCRIPTION
    If provided with valid access parameters and a valid device uid, this will return the device info available from the Datto RMM API

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER deviceId
    Datto-defined uid. From within a machine this can be collected via
    
    $deviceId = Get-DeviceId

    .OUTPUTS
    [System.Object] custom object containing device data

    .EXAMPLE
    $deviceData = Get-DeviceData -deviceId $deviceId
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$deviceId
    )   
    $response = New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "get" -apiRequest "device/$deviceId"
    return $response
}
function Get-DeviceOpenAlerts {
    <#
    .SYNOPSIS 
    Gets device data from the Datto RMM API

    .DESCRIPTION
    If provided with valid access parameters and a valid device uid, this will return the device info available from the Datto RMM API

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER deviceId
    Datto-defined uid. From within a machine this can be collected via
    
    $deviceId = Get-DeviceId

    .OUTPUTS
    [System.Object] custom object containing open alerts for device

    .EXAMPLE
    $deviceData = Get-DeviceOpenAlerts -deviceId $deviceId
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$deviceId
    )   
    $response = New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "get" -apiRequest "device/$deviceId/alerts/open"
    return $response
}
function Get-DevicePatchStatus {
    <#
    .SYNOPSIS 
    Gets device patch status from the Datto RMM API

    .DESCRIPTION
    If provided with valid access parameters and a valid device uid, this will return the patch status from the Datto RMM API

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER deviceId
    Datto-defined uid. From within a machine this can be collected via
    
    $deviceId = Get-DeviceId

    .OUTPUTS
    [String] patch status

    .EXAMPLE
    $devicePatchStatus = Get-DevicePatchStatus -deviceId $deviceId

    .NOTES
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$deviceId
    )   
    $deviceData = Get-DeviceData -apiAccessToken $apiAccessToken -apiUrl $apiUrl -deviceId $deviceId
    return $deviceData.patchManagement.patchStatus
}
function Get-Devices {
    <#
    .SYNOPSIS 
    Gets device data for all devices from the Datto RMM API

    .DESCRIPTION
    If provided with valid access parameters, this will return the device info available from the Datto RMM API

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .OUTPUTS
    [System.Object] custom object containing device data

    .EXAMPLE
    $devices = Get-Devices
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl

    )   
    $response = New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "get" -apiRequest "account/devices"
    return $response
}
function New-DattoRmmApiAccessToken {
    <#
    .SYNOPSIS 
    Generates a new Datto RMM API Access Token

    .DESCRIPTION
    If provided with a valid API key pair, this function returns an OAuth2 authorization token
    See https://help.aem.autotask.net/en/Content/2SETUP/APIv2.htm for details on enabling the API and defining key pairs

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER accessKey
    API Access Key

    .PARAMETER secretKey
    API Secret Key

    .OUTPUTS
    [String] Authorization Token

    .EXAMPLE
    $apiAccessToken = New-DattoRmmApiAccessToken -apiUrl = "https://zinfandel-api.centrastage.net" - accessKey = "fjlkdjk" -secretKey = "adlsfaffdk"

    .NOTES
    #>
	param
	(
        [parameter(Mandatory=$true)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [string]$apiUrl,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$accessKey,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$secretKey
	)

	# Specify security protocols
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'

	# Convert password to secure string
	$securePassword = ConvertTo-SecureString -String 'public' -AsPlainText -Force

	# Define parameters for Invoke-WebRequest cmdlet
	$params = @{
		Credential	=	New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ('public-client', $securePassword)
		Uri			=	'{0}/auth/oauth/token' -f $apiUrl
		Method      =	'POST'
		ContentType = 	'application/x-www-form-urlencoded'
		Body        = 	'grant_type=password&username={0}&password={1}' -f $accessKey, $secretKey
	}

	# Request access token
	return ( Invoke-WebRequest @params -UseBasicParsing | ConvertFrom-Json ).access_token
}
function New-DattoRmmApiRequest {
    <#
    .SYNOPSIS 
    Performs a query against the Datto RMM API

    .DESCRIPTION
    If provided with a valid API key pair OR a valid API access token, this will return the result of the specified API request
    See https://help.aem.autotask.net/en/Content/2SETUP/APIv2.htm for details on enabling the API and defining key pairs

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER apiMethod
    API SMethod (GET, POST, or PATCH)

    .PARAMETER apiRequest
    Endpoint for API request.
    For endpoint information, see Swagger links at https://help.aem.autotask.net/en/Content/2SETUP/APIv2.htm

    .PARAMETER apiRequestBody
    json-formatted body for POST or PATCH requests

    .OUTPUTS
    [System.Object] custom object containing request response data

    .EXAMPLE
    $response = New-DattoRmmApiRequest -apiUrl "https://zinfandel-api.centrastage.net" -apiAccessToken "fjdfkdfjfeifj" -apiMethod "get" -apiRequest "device/$deviceId"

    #>
    param 
    (
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(Mandatory=$true)]
        [ValidateSet("GET","POST","PATCH")]
        [String]$apiMethod,

        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [String]$apiRequest,

        [parameter(Mandatory=$false)]
        [String]$apiRequestBody
    )

    # some calls will just use the endpoint to add to the base $apiUrl (e.g. 'account/devices'), other calls
    # will include the entire uri (e.g. when using nextPageUrl or prevPageUrl)
    if ( $apiRequest.Substring(0,[math]::min($apiRequest.Length,$apiUrl.Length)) -eq $apiUrl ) {
        $uri = $apiRequest
    } else {
        $uri = "$apiUrl/api/v2/$apiRequest"
    }

    #set the parameters for the request
    $params = @{
        Uri         =	$uri
        Method      =	$apiMethod
        ContentType	= 	'application/json'
        Headers     =	@{
            'Authorization'	=	'Bearer {0}' -f $apiAccessToken
        }
    }

    #if body was defined (patch or put), add to params
    If ( $apiRequestBody ) {
        $params.Add( 'Body' , $apiRequestBody )
    }

    #make api request
    $response = ( Invoke-WebRequest @params -UseBasicParsing ) | Select-Object StatusCode,Content

    #if we got good data, convert it from json before returning it
    if ( $response.statusCode -eq 200 ) {
        $content = $response.content | ConvertFrom-Json
        if ( $null -eq $content.pageDetails ) {
            return $content
        } else {
            $member = $content | Get-Member | Where-Object { $_.MemberType -eq "NoteProperty" -and $_.Name -ne "pageDetails" } | Select-Object -ExpandProperty 'name' 
            if ( $member.GetTypeCode() -ne "String" ) {
                throw "Unable to process API response."
            }
            if ( $null -eq $content.pageDetails.nextPageUrl ) {
                return $content.$member
            } else {
                $paramsRest = @{
                    apiUrl         	=	$apiUrl
                    apiAccessToken  =	$apiAccessToken
                    apiMethod      	=	$apiMethod
                    apiRequest      =   $content.pageDetails.nextPageUrl
                }
                $restOfResponse = New-DattoRmmApiRequest @paramsRest  
                return $content.$member + $restOfResponse
            }
        }
    }
    
    # return reponse as long as status is not 429 or 403 (indicating rate limit issues that neccessitate a cool-down)
    if ( $response.statusCode -ne 429 -and $response.statusCode -ne 403 ) {
        return $response.content
    } else {
        #pause for cool down and try again
        if ( $response.statusCode -eq 429 ) {
            Start-Sleep -s 61
        } elseif ( $response.statusCode -eq 403 ) {
            Start-Sleep -s 601
        } 
        
        #set the params to call this function again with the same settings
        $paramsOrig = @{
            apiUrl         	=	$apiUrl
            apiAccessToken  =	$apiAccessToken
            apiMethod      	=	$apiMethod
            apiRequest      =   $apiRequest
        }
        return New-DattoRmmApiRequest @paramsOrig
    }
}
function Set-DeviceOpenAlertToResolved {
    <#
    .SYNOPSIS 
    Sets an alert to 'resolved' status

    .DESCRIPTION
    If provided with valid access parameters and a valid alert uid, this will set that alert to 'resolved' status

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER alertUid
    Datto-defined alert uid. 

    .EXAMPLE
    $deviceData = Set-DeviceOpenAlertToResolved -alertUid $alertUid
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$alertUid
    )   
    $response = New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "post" -apiRequest "alert/$alertUid/resolve"
    return $response
}
function Set-DeviceUdf {
    <#
    .SYNOPSIS 
    Sets Datto RMM UDF to a specified value for a single device, devices at a site, or devices in an account

    .DESCRIPTION
    If provided with valid access parameters this will set UDF values via the API. This will impact devices whether or not they are online.

    .PARAMETER apiAccessToken
    API Access Token generated by New-DattoRmmApiAccessToken.

    .PARAMETER apiUrl
    Region-specific API Url. Allowable values are:

    https://pinotage-api.centrastage.net

    https://merlot-api.centrastage.net

    https://concord-api.centrastage.net

    https://zinfandel-api.centrastage.net

    https://syrah-api.centrastage.net

    .PARAMETER deviceId
    Datto-defined uid. From within a machine this can be collected via
    $deviceId = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\CentraStage' -Name deviceId).deviceId

    .PARAMETER siteId
    Datto-defined uid. 

    .PARAMETER udf
    UDF number (1-30)

    .PARAMETER value
    Value for the udf. User-defined fields have a limit of 255 characters.
    #>
    param
	(
        [parameter(Mandatory=$false)]
        [validateNotNullorEmpty()]
        [String]$apiAccessToken=$global:dattoRmmApiAccessToken,

        [parameter(Mandatory=$false)]
        [ValidateSet("https://pinotage-api.centrastage.net","https://merlot-api.centrastage.net","https://concord-api.centrastage.net","https://zinfandel-api.centrastage.net","https://syrah-api.centrastage.net")]
        [String]$apiUrl=$global:dattoRmmApiUrl,

        [parameter(Mandatory=$true,ParameterSetName = "Set value for a single device")]
        [validateNotNullorEmpty()]
        [string]$deviceId,

        [parameter(Mandatory=$true,ParameterSetName = "Set value for all devices at a site")]
        [validateNotNullorEmpty()]
        [string]$siteId,

        [parameter(Mandatory=$true,ParameterSetName = "Set value for a single device")]
        [parameter(Mandatory=$true,ParameterSetName = "Set value for all devices at a site")]
        [parameter(Mandatory=$true,ParameterSetName = "Set value for all devices in account")]
        [ValidateRange(1,30)]
        [int32]$udf,

        [parameter(Mandatory=$true,ParameterSetName = "Set value for a single device")]
        [parameter(Mandatory=$true,ParameterSetName = "Set value for all devices at a site")]
        [parameter(Mandatory=$true,ParameterSetName = "Set value for all devices in account")]
        [ValidateLength(0,255)]
        [AllowEmptyString()]
        [string]$value
    )   

    $requestBody = @{
        "udf$udf" = $value
    } | ConvertTo-Json

    if ( ( $PSBoundParameters.ContainsKey( 'deviceId')  ) -eq $true ) {
        $apiRequest = "device/$deviceId"
    } elseif ( ( $PSBoundParameters.ContainsKey( 'siteId')  ) -eq $true ) {
        $apiRequest = "site/$siteId/devices"
    } else {
        $apiRequest = "account/devices"
    }

    $devices = New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "get" -apiRequest $apiRequest
    foreach ( $device in $devices ) {
        $deviceId = $device.uid
        New-DattoRmmApiRequest -apiAccessToken $apiAccessToken -apiUrl $apiUrl -apiMethod "post" -apiRequest "device/$deviceId/udf" -apiRequestBody $requestBody
    }
}
function Confirm-DellDevice {
    <#
    .SYNOPSIS 
    Confirms that device was manufactured by Dell

    .DESCRIPTION
    Get the device manufacturer and confirms that it is Dell

    .NOTES

    .EXAMPLE
    if ( Confirm-DellDevice -eq $true ) { ... }
    #>

    return ( ( Get-WmiObject -class Win32_ComputerSystem ).Manufacturer -eq "Dell Inc." )
}
function Get-DellServiceTag {
    <#
    .SYNOPSIS 
    Gets Dell Service Tag

    .DESCRIPTION
    Gets the Dell Service Tag for the local machine

    .NOTES

    .EXAMPLE
    $serviceTag = Get-DellServiceTag
    #>
    
    if ( Confirm-DellDevice ) {
        $serviceTag = ( Get-WmiObject win32_SystemEnclosure ).serialNumber
        if ( $null -eq $serviceTag ) {
            $serviceTag = ( Get-WmiObject Win32_ComputerSystem ).serialNumber
        }
        if ( $null -eq $serviceTag ) {
            Write-Log -Message "Unable to find service tag" -EntryType "Error"
            return $null
        }
        if ( ( $serviceTag.GetType() ).Name -eq "Object[]" ) {
            return $serviceTag[0]
        } else {
            return $serviceTag
        }
    } else {
        Write-Log -Message "This is not a Dell device" -EntryType "Warning"
        return $null
    }

}
function Get-DellWarrantyApiToken {
    <#
    .SYNOPSIS 
    Gets Dell Warranty API Token

    .DESCRIPTION
    Given a client id and a client secret, this function returns a token for accessing the Dell Warranty API

    .PARAMETER clientId
    Dell Warranty API client_id value

    .PARAMETER clientSecret
    Dell Warranty API client_secret value

    .NOTES

    .EXAMPLE
 
    #>
    param(
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$clientId = $global:dellWarrantyApiClientId,
        
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$clientSecret = $global:dellWarrantyApiClientSecret
    )

    if ( $global:dellApiConfigured -eq $false ) {
        return $null
    }
    
    $oAuthUri = "https://apigtwb2c.us.dell.com/auth/oauth/v2/token"

    $oAuth = "$clientId`:$clientSecret"
    
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($oAuth)
    $encodedOAuth = [Convert]::ToBase64String($bytes)
    $headers = @{ }
    $headers.Add("authorization", "Basic $encodedOAuth")
    $authbody = 'grant_type=client_credentials'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {
        $oAuthResult = Invoke-RESTMethod -Method Post -Uri $oAuthUri -Body $authbody -Headers $headers
        $token = $oAuthResult.access_token
        return $token
    }
    catch {
        $errorMessage = $Error[0]
        Write-Error $errorMessage
        return $null        
    }
    
}
function Get-DellWarrantyInfo {
    <#
    .SYNOPSIS 
    Gets Dell Warranty Info

    .DESCRIPTION
    Uses the Dell API to get warranty info for a given service tag number

    .PARAMETER apiKey
    Dell apiKey

    .PARAMETER serviceTag
    Service tag to look up

    .NOTES

    .EXAMPLE
    $warrantyInfo = Get-DellWarrantyInfo -serviceTag 'ABCDEF'
    #>
    param(
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$token = $global:dellWarrantyApiToken,
        
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$serviceTag
    )

    if ( $global:dellApiConfigured -eq $false ) {
        return $null
    }

    $endpoint = "https://apigtwb2c.us.dell.com/PROD/sbil/eapi/v5/asset-entitlements"

    $headers = @{"Accept" = "application/json" }
    $headers.Add("Authorization", "Bearer $token")

    $params = @{ }
    $params = @{servicetags = $servicetag; Method = "GET" }

    $response = Invoke-RestMethod -Uri $endpoint -Headers $headers -Body $params -Method Get -ContentType "application/json"

    if ( $response.invalid -eq $false ) {
        return $response
    } else {
        Write-Log -message "Service tag ($serviceTag) invalid" -entryType Error 
        return $null
    }
}
function Send-MsTeamsMessage {
    <#
    .SYNOPSIS 
    Posts a message to Microsoft Teams

    .DESCRIPTION
    Uses a pre-created webhook to post a message to a Teams channel

    .PARAMETER webhook
    uri for webhook

    .PARAMETER summary
    Message summary

    .PARAMETER title
    Message title

    .PARAMETER text
    Message text

    .NOTES
    Summary is what shows up in the teams feed

    Title is what is bold/h1 in the message itself
    
    Text is plain text in the message itself
    .EXAMPLE
    Send-MsTeamsMessage -summary "Critical event" -title "Hard Drive Failure" -text "Hard drive has failed on server at hospital" -webhook "https://outlook.office.com/webhook/00000000-0000-0000-0000-000000000000000000000-0000-0000-0000-000000000000/IncomingWebhook/00000000000000000000000000000000/00000000-0000-0000-0000-000000000000"
    #>
    param(
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$webhook = $msTeamsWebhook,
        
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$summary,

        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$title,

        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$text
    )

    if ( $global:o365Configured -eq $false ) {
        return $null
    }
    $body = ConvertTo-JSON @{
        summary = $summary
        text = $text
        title = $title
    }

    Invoke-RestMethod -uri $webhook -Method Post -body $body -ContentType 'application/json' -UseBasicParsing

}
function Send-Office365MailMessage {
    <#
    .SYNOPSIS 
    Posts a message via o365 email

    .DESCRIPTION
    Sends an email from an Office365 account with HTML-encoded message content.

    .PARAMETER From
    Email address to send from

    .PARAMETER Credential
    Credential object containing credentials for $o365Account

    .PARAMETER To
    Email address to send to

    .PARAMETER Subject
    Email subject

    .PARAMETER BodyAsHtml
    Message (as html)
    #>
    
    param(
        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [string]$From = $O365Account,

        [parameter(Mandatory=$false)]
        [validateNotNullOrEmpty()]
        [PSCredential]$Credential = $o365AccountCredential,
        
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$To,

        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$Subject,

        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]$BodyAsHtml
    )

    if ( $global:o365Configured -eq $false ) {
        return $null
    }
    $o365SmtpServer = "smtp.office365.com"
    $o365SmtpPort = "587"

    Send-MailMessage -From $from -To $to -Subject $subject -bodyAsHtml $bodyAsHtml -SmtpServer $o365SmtpServer -Port $o365SmtpPort -UseSsl -Credential $credential

}
function Get-InstalledSoftware {

    <#
    .SYNOPSIS 
    Returns a list of installed software without using wmi32

    .DESCRIPTION
    get-wmiobject win32_product is the natural way to get installed programs, but it has potentially disasterous side effects. When executed,
    it performs a consistency check on all software and may "reconfigure" products. This script gets a list of installed software without any
    negative/unintended side effects.

    .PARAMETER filterName
    Optional filter to apply to returned list

    .OUTPUTS
    [PSCustomObject] array

    .EXAMPLE
    $installedSoftware - Get-InstalledSoftware

    .NOTES
    This function was adapted from a script originally authored by Boe Prox and modified by Michael McCool and sourced from https://mcpmag.com/articles/2017/07/27/gathering-installed-software-using-powershell.aspx.
    
    .LINK
    https://gregramsey.net/2012/02/20/win32_product-is-evil/
    #>

    Param ( 
        # Parameter help description
        [Parameter( Mandatory = $false )]
        [string]$filterName
    )

    #$programs = @{displayName = ;Version = ;InstallDate = ;Publisher = ;UninstallString = ;InstallLocation = ;InstallSource = ;HelpLink = ;EstimatedSizeMB = }
    $softwareList = @()

    $paths  = @( 
        "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall",
        "SOFTWARE\\Wow6432node\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
    )    

    foreach ( $path in $paths ) {
        try {
            $reg = [microsoft.win32.registrykey]::OpenRemoteBaseKey( 'LocalMachine',$env:COMPUTERNAME,'Registry64' )
        } catch {
            Write-Log -message "$_" -entryType warning 
            Continue   
        }
        
        #  Drill down into the Uninstall key using the OpenSubKey Method 
  
        try {  
            $regkey = $reg.OpenSubKey( $path )  
            # Retrieve an array of strings that contains all the subkey names 
            $subkeys = $regkey.GetSubKeyNames()      
            # Open each Subkey and use GetValue Method to return the required  values for each 
            ForEach ( $key in $subkeys ){   
                $thisKey = $Path+"\\"+$key 
                try {  
                    $thisSubKey = $reg.OpenSubKey( $thisKey )   
                    # Prevent Objects with empty displayName 
                    $displayName =  $thisSubKey.getValue( "displayName" )
                    if ( $displayName -notlike $filterName -and $PSBoundParameters.ContainsKey( 'filterName' ) ) {
                        $displayName = $null
                    }
                    if ( $displayName -and $displayName -notmatch '^Update for|rollup|^Security Update|^Service Pack|^HotFix' ) {
                        $date = $thisSubKey.GetValue( 'InstallDate' )
                        if ( $date ) {
                            try {
                                $date = [datetime]::ParseExact( $date, 'yyyyMMdd', $Null )
                            } 
                            catch{
                                Write-Warning "$( $Computer ): $_ <$( $date )>"
                                Write-Log -message "$_ <$( $date )>" -entryType warning 
                                $date = $Null
                            }
                        } 

                        $publisher = try {
                            $thisSubKey.GetValue( 'Publisher' ).Trim()
                        } catch {
                            $thisSubKey.GetValue( 'Publisher' )
                        }

                        $version = try {
                            #Some weirdness with trailing [char]0 on some strings
                            $thisSubKey.GetValue( 'DisplayVersion' ).TrimEnd( ( [char[]]( 32,0 ) ) )
                        } catch {
                            $thisSubKey.GetValue( 'DisplayVersion' )
                        }

                        $uninstallString = try {
                            $thisSubKey.GetValue( 'UninstallString' ).Trim()
                        } catch {
                            $thisSubKey.GetValue( 'UninstallString' )
                        }

                        $installLocation = try {
                            $thisSubKey.GetValue( 'InstallLocation' ).Trim()
                        } catch {
                            $thisSubKey.GetValue( 'InstallLocation' )
                        }

                        $installSource = try {
                            $thisSubKey.GetValue( 'InstallSource' ).Trim()
                        } catch {
                            $thisSubKey.GetValue( 'InstallSource' )
                        }

                        $helpLink = try {
                            $thisSubKey.GetValue( 'HelpLink' ).Trim()
                        } catch {
                            $thisSubKey.GetValue( 'HelpLink' )
                        }
                        
                        $object = [PSCustomObject]@{ 
                            displayName = $displayName
                            version  = $version
                            installDate = $date
                            publisher = $publisher
                            uninstallString = $uninstallString
                            installLocation = $installLocation
                            installSource  = $installSource
                            helpLink = $helpLink
                            estimatedSizeMB = [decimal]( [math]::Round( ( $thisSubKey.GetValue( 'EstimatedSize' )*1024 )/1MB,2 ) )
                        }
                        $softwareList +=  $object
                    }
                } catch {
                    Write-Warning "$Key : $_"
                }
            }
        } catch  {}
        $reg.Close() 
    }
    return $softwareList
}
function Set-RegistryKeyValue {
    <#
    .SYNOPSIS 
    Sets the value of a registry key

    .DESCRIPTION
    Finds a given registry key (creating one if necessary) and sets it to a given value

    .PARAMETER key
    Registry path to set
    
    .PARAMETER key
    Registry key to set

    .PARAMETER value
    Value to set the registry key value to

    .PARAMETER valueType
    Value type (currently only DWORD is supported)

    .EXAMPLE
    Set-RegistryKeyValue -path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\' -key 'EnableModuleLogging' -value '0'
    #>
    param (
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]
        $path,
        
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]
        $key,
        
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]
        $value,

        [parameter(Mandatory=$false)]
        [ValidateSet("DWORD","String")]
        [string]
        $valueType="DWORD"

    )
    
    if ( !( Test-Path $path ) ) {
        write-host "x"
        New-Item -Path $path -Force | Out-Null
    }
    write-host "y"
    write-host "$valueType"
    New-ItemProperty -Path $path -Name $key -Value $value -PropertyType $valueType -Force | Out-Null
    
}
function Test-Credentials {
    <#
    .SYNOPSIS 
    Tests a given username and password

    .DESCRIPTION
    Tests a given username and password to see if they are valid on the current machine. Returns a boolean with the result

    .PARAMETER un
    Username to test
    
    .PARAMETER pw
    Password to test

    .EXAMPLE
    Test-Credentials -username 'someuser' -password 'somepassword'
    #>
    param (
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]
        $un,
        
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]
        $pw

    )
    
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $dirService = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('machine',$env:computername)
    $result = $dirService.ValidateCredentials($un, $pw)
    return $result
}
function Test-ModuleDataSecurity {
    <#
    .SYNOPSIS 
    Checks whether module logging is turned on and exits if so

    .DESCRIPTION
    If module logging is enabled, private data may be written to the windows event log. This function checks for whether logging is enabled and exits if it is.

    .EXAMPLE
    $moduleDataSecure = Test-ModuleDataSecurity

    .OUTPUTS
    [Boolean]

    .NOTES
    #>
    $Key32 = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging'
    $Key64 = 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell\ModuleLogging'
    $Value = 'EnableModuleLogging'

    $loggingEnabled1 = ( Test-RegistryKeyValueData -key $key32 -Value $Value -TestValueData '1' ) -eq $true
    $loggingEnabled2 = ( Test-RegistryKeyValueData -key $key64 -Value $Value -TestValueData '1' ) -eq $true
    
    if ( $loggingEnabled1 -or $loggingEnabled2 ) {
        return $false
    } else {
        return $true
    }
}
<#
.SYNOPSIS
    Test the pending reboot status on a local and/or remote computer.

.DESCRIPTION
    This function will query the registry on a local and/or remote computer and determine if the
    system is pending a reboot, from Microsoft/Windows updates, Configuration Manager Client SDK, Pending
    Computer Rename, Domain Join, Pending File Rename Operations and Component Based Servicing.

    ComponentBasedServicing = Component Based Servicing
    WindowsUpdate = Windows Update / Auto Update
    CCMClientSDK = SCCM 2012 Clients only (DetermineifRebootPending method) otherwise $null value
    PendingComputerRenameDomainJoin = Detects a pending computer rename and/or pending domain join
    PendingFileRenameOperations = PendingFileRenameOperations, when this property returns true,
                                  it can be a false positive
    PendingFileRenameOperationsValue = PendingFilerenameOperations registry value; used to filter if need be,
                                       Anti-Virus will leverage this key property for def/dat removal,
                                       giving a false positive

.PARAMETER ComputerName
    A single computer name or an array of computer names.  The default is localhost ($env:COMPUTERNAME).

.PARAMETER Credential
    Specifies a user account that has permission to perform this action. The default is the current user.
    Type a username, such as User01, Domain01\User01, or User@Contoso.com. Or, enter a PSCredential object,
    such as an object that is returned by the Get-Credential cmdlet. When you type a user name, you are
    prompted for a password.

.PARAMETER Detailed
    Indicates that this function returns a detailed result of pending reboot information, why the system is
    pending a reboot, not just a true/false response.

.PARAMETER SkipConfigurationManagerClientCheck
    Indicates that this function will not test the Client SDK WMI class that is provided by the System
    Center Configuration Manager Client.  This parameter is useful when SCCM is not used/installed on
    the targeted systems.

.PARAMETER SkipPendingFileRenameOperationsCheck
    Indicates that this function will not test the PendingFileRenameOperations MultiValue String property
    of the Session Manager registry key.  This parameter is useful for eliminating possible false positives.
    Many Anti-Virus packages will use the PendingFileRenameOperations MultiString Value in order to remove
    stale definitions and/or .dat files.

.EXAMPLE
    PS C:\> Test-PendingReboot

    ComputerName IsRebootPending
    ------------ ---------------
    WKS01                   True

    This example returns the ComputerName and IsRebootPending properties.

.EXAMPLE
    PS C:\> (Test-PendingReboot).IsRebootPending
    True

    This example will return a bool value based on the pending reboot test for the local computer.

.EXAMPLE
    PS C:\> Test-PendingReboot -ComputerName DC01 -Detailed

    ComputerName                     : dc01
    ComponentBasedServicing          : True
    PendingComputerRenameDomainJoin  : False
    PendingFileRenameOperations      : False
    PendingFileRenameOperationsValue :
    SystemCenterConfigManager        : False
    WindowsUpdateAutoUpdate          : True
    IsRebootPending                  : True

    This example will test the pending reboot status for dc01, providing detailed information

.EXAMPLE
    PS C:\> Test-PendingReboot -ComputerName DC01 -SkipConfigurationManagerClientCheck -SkipPendingFileRenameOperationsCheck -Detailed

    CommputerName                    : dc01
    ComponentBasedServicing          : True
    PendingComputerRenameDomainJoin  : False
    PendingFileRenameOperations      : False
    PendingFileRenameOperationsValue :
    SystemCenterConfigManager        :
    WindowsUpdateAutoUpdate          : True
    IsRebootPending                  : True

.LINK
    Background:
    https://blogs.technet.microsoft.com/heyscriptingguy/2013/06/10/determine-pending-reboot-statuspowershell-style-part-1/
    https://blogs.technet.microsoft.com/heyscriptingguy/2013/06/11/determine-pending-reboot-statuspowershell-style-part-2/

    Component-Based Servicing:
    http://technet.microsoft.com/en-us/library/cc756291(v=WS.10).aspx

    PendingFileRename/Auto Update:
    http://support.microsoft.com/kb/2723674
    http://technet.microsoft.com/en-us/library/cc960241.aspx
    http://blogs.msdn.com/b/hansr/archive/2006/02/17/patchreboot.aspx

    CCM_ClientSDK:
    http://msdn.microsoft.com/en-us/library/jj902723.aspx

.NOTES
    Author:  Brian Wilhite
    Email:   bcwilhite (at) live.com
    Source: https://github.com/bcwilhite/PendingReboot
    
    MIT License

    Copyright (c) 2018 Brian Wilhite

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
#>

function Test-PendingReboot
{
    [CmdletBinding()]
    param(
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias("CN", "Computer")]
        [String[]]
        $ComputerName = $env:COMPUTERNAME,

        [Parameter()]
        [System.Management.Automation.PSCredential]
        [System.Management.Automation.CredentialAttribute()]
        $Credential,

        [Parameter()]
        [Switch]
        $Detailed,

        [Parameter()]
        [Switch]
        $SkipConfigurationManagerClientCheck,

        [Parameter()]
        [Switch]
        $SkipPendingFileRenameOperationsCheck
    )

    process
    {
        foreach ($computer in $ComputerName)
        {
            try
            {
                $invokeWmiMethodParameters = @{
                    Namespace    = 'root/default'
                    Class        = 'StdRegProv'
                    Name         = 'EnumKey'
                    ComputerName = $computer
                    ErrorAction  = 'Stop'
                }

                $hklm = [UInt32] "0x80000002"

                if ($PSBoundParameters.ContainsKey('Credential'))
                {
                    $invokeWmiMethodParameters.Credential = $Credential
                }

                ## Query the Component Based Servicing Reg Key
                $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\')
                $registryComponentBasedServicing = (Invoke-WmiMethod @invokeWmiMethodParameters).sNames -contains 'RebootPending'

                ## Query WUAU from the registry
                $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\')
                $registryWindowsUpdateAutoUpdate = (Invoke-WmiMethod @invokeWmiMethodParameters).sNames -contains 'RebootRequired'

                ## Query JoinDomain key from the registry - These keys are present if pending a reboot from a domain join operation
                $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SYSTEM\CurrentControlSet\Services\Netlogon')
                $registryNetlogon = (Invoke-WmiMethod @invokeWmiMethodParameters).sNames
                $pendingDomainJoin = ($registryNetlogon -contains 'JoinDomain') -or ($registryNetlogon -contains 'AvoidSpnSet')

                ## Query ComputerName and ActiveComputerName from the registry and setting the MethodName to GetMultiStringValue
                $invokeWmiMethodParameters.Name = 'GetMultiStringValue'
                $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName\', 'ComputerName')
                $registryActiveComputerName = Invoke-WmiMethod @invokeWmiMethodParameters

                $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName\', 'ComputerName')
                $registryComputerName = Invoke-WmiMethod @invokeWmiMethodParameters

                $pendingComputerRename = $registryActiveComputerName -ne $registryComputerName -or $pendingDomainJoin

                ## Query PendingFileRenameOperations from the registry
                if (-not $PSBoundParameters.ContainsKey('SkipPendingFileRenameOperationsCheck'))
                {
                    $invokeWmiMethodParameters.ArgumentList = @($hklm, 'SYSTEM\CurrentControlSet\Control\Session Manager\', 'PendingFileRenameOperations')
                    $registryPendingFileRenameOperations = (Invoke-WmiMethod @invokeWmiMethodParameters).sValue
                    $registryPendingFileRenameOperationsBool = [bool]$registryPendingFileRenameOperations
                }

                ## Query ClientSDK for pending reboot status, unless SkipConfigurationManagerClientCheck is present
                if (-not $PSBoundParameters.ContainsKey('SkipConfigurationManagerClientCheck'))
                {
                    $invokeWmiMethodParameters.NameSpace = 'ROOT\ccm\ClientSDK'
                    $invokeWmiMethodParameters.Class = 'CCM_ClientUtilities'
                    $invokeWmiMethodParameters.Name = 'DetermineifRebootPending'
                    $invokeWmiMethodParameters.Remove('ArgumentList')

                    try
                    {
                        $sccmClientSDK = Invoke-WmiMethod @invokeWmiMethodParameters
                        $systemCenterConfigManager = $sccmClientSDK.ReturnValue -eq 0 -and ($sccmClientSDK.IsHardRebootPending -or $sccmClientSDK.RebootPending)
                    }
                    catch
                    {
                        $systemCenterConfigManager = $null
                        Write-Verbose -Message ($script:localizedData.invokeWmiClientSDKError -f $computer)
                    }
                }

                $isRebootPending = $registryComponentBasedServicing -or `
                    $pendingComputerRename -or `
                    $pendingDomainJoin -or `
                    $registryPendingFileRenameOperationsBool -or `
                    $systemCenterConfigManager -or `
                    $registryWindowsUpdateAutoUpdate

                if ($PSBoundParameters.ContainsKey('Detailed'))
                {
                    [PSCustomObject]@{
                        ComputerName                     = $computer
                        ComponentBasedServicing          = $registryComponentBasedServicing
                        PendingComputerRenameDomainJoin  = $pendingComputerRename
                        PendingFileRenameOperations      = $registryPendingFileRenameOperationsBool
                        PendingFileRenameOperationsValue = $registryPendingFileRenameOperations
                        SystemCenterConfigManager        = $systemCenterConfigManager
                        WindowsUpdateAutoUpdate          = $registryWindowsUpdateAutoUpdate
                        IsRebootPending                  = $isRebootPending
                    }
                }
                else
                {
                    [PSCustomObject]@{
                        ComputerName    = $computer
                        IsRebootPending = $isRebootPending
                    }
                }
            }

            catch
            {
                Write-Verbose "$Computer`: $_"
            }
        }
    }
}
function Test-RegistryKeyValueData {
    <#
    .SYNOPSIS 
    Tests the value of a registry key

    .DESCRIPTION
    Returns true if a registry value exists and matches the given value. Otherwise, returns false.

    .PARAMETER Key
    Registry key to look in 

    .PARAMETER Value
    Value to check (must be a string. If not, this function will return $false)

    .PARAMETER TestValueData
    Value data to compare to

    .OUTPUTS
    [Boolean]

    .EXAMPLE
    Test-registryentry -path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging' -key 'EnableModuleLogging' -value '1'
    #>
    param (
        [parameter(Mandatory=$true)]
        [validateNotNullOrEmpty()]
        [string]
        $Key,
        
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]
        $Value,

        [parameter(Mandatory=$true)]
        [AllowEmptyString()]
        [string]
        $TestValueData
    )

    if ( ( Test-Path -Path $Key ) -eq $false ) {
        return $false
    }

    $KeyItem = Get-Item -Path $Key
    if ( $null -eq ( $KeyItem.Property | Where-Object { $_ -eq $Value }  ) ) {
        return $false
    }

    $ValueData = Get-ItemProperty -Path $Key | Select-Object -ExpandProperty $Value
    if ( $ValueData.GetTypeCode() -eq "String" ) {
        return $TestValueData -eq $ValueData
    } else {
        return $false
    }
}
function Test-VpnConnection {
    <#
    .SYNOPSIS 
    Checks whether a VPN is currently active

    .DESCRIPTION
    Returns true if device is connected to VPN, false otherwise

    .OUTPUTS
    [Boolean]

    .EXAMPLE
    Test-VpnConnection
    #>


    $connectedVpn = Get-VPNconnection -AllUserConnection | Where-Object { $_.ConnectionStatus -eq 'Connected' }

    if ( $connectedVpn.Count -eq 0 ) {
        return $false
    } else {
        return $true
    }
}
function Write-Log {
    <#
    .SYNOPSIS 
    Writes to the event log and the Datto RMM stdout window.

    .DESCRIPTION
    Creates a Weindows event event log source "Datto RMM" and writes log messages to that log. Simultaneously writes to stdout.

    .PARAMETER message
    The text to write to the event log and stdout 

    .PARAMETER entryType
    The event log entry type. Must be "Information", "Warning", or "Error"

    .PARAMETER eventID
    The event log event id (default = 20). 0 = Adding Windows Eventlog source, 10 = Global Functions, 20 = Script components

    .EXAMPLE
    Write-Log -Message "This is a log message`nThat spans two lines" -EntryType "Information" -EventID 10
    This example writes an information message to the event log and puts the same text into the stdout so it is viewable from within the Datto RMM interface

    .NOTES

    #>
    param(
        [parameter(Mandatory=$true)]
        [validateNotNullorEmpty()]
        [string]$message,

        [parameter(Mandatory=$true)]
        [ValidateSet("Information","Warning","Error")]
        [string]$entryType,
        
        [parameter(Mandatory=$false)]
        [ValidateSet("0","10","20")]
        [int]$eventID=20
    )

    $eventLogSourceName = "Datto RMM";

    #create the event log if neccessary
    if ([System.Diagnostics.EventLog]::SourceExists($eventLogSourceName) -eq $false)
    {
        $newLogMessage = "Started event log for $eventLogSourceName"
        New-EventLog -LogName Application -Source $eventLogSourceName        
        Write-EventLog -LogName Application -Source $eventLogSourceName -EntryType Information -EventId 0 -Message $newLogMessage
        Write-Host $newLogMessage
    }
    Write-EventLog -LogName Application -Source $eventLogSourceName -EntryType $entryType -EventId $eventID -Message $message
    Write-Host $message
}
